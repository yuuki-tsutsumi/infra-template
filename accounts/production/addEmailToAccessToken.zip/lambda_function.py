def lambda_handler(event, context):
    event['response'] = {
        "claimsAndScopeOverrideDetails": {
            "accessTokenGeneration": {
                "claimsToAddOrOverride": {
                    'email': event['request']['userAttributes'].get('email')
                },
            }
        }
    }
    return event